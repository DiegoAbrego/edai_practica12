def fibonacci_iterativo_v2(numero):
 f1=0
 f2=1
 for i in range(1, numero-1):
     f1,f2=f2,f1+f2 #Asignación paralela
 return f2

print(str(fibonacci_iterativo_v2(13)))

def fibonacci_recursivo(numero):
    if numero ==1:
        return 0
    if numero == 2 or numero == 3:
        return 1

    return fibonacci_recursivo(numero-1) + fibonacci_recursivo(numero-2)

print(str(fibonacci_recursivo(13)))

memoria = {1:0,2:1,3:1}

def fibonacci_memo(numero):
    if numero in memoria:
        return memoria[numero]
    memoria[numero] = fibonacci_memo(numero-1) +fibonacci_memo(numero-2)
    print(memoria)
    return memoria[numero]

print(fibonacci_memo(13))
print(fibonacci_memo(11))
