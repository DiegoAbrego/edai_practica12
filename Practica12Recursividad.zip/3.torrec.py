import turtle
import argparse
wn = turtle.Screen()
wn.bgcolor("lightgreen")
tess = turtle.Turtle()
tess.shape("turtle")
tess.color("blue")

def recorrido_recursivo(tortuga, espacio, huellas):
    if huellas > 0:
        tortuga.stamp()
        espacio = espacio + 3
        tortuga.forward(espacio)
        tortuga.right(24)
        recorrido_recursivo(tortuga, espacio, huellas-1)

ap = argparse.ArgumentParser()
#El dato de entrada se ingresa con la bandera --huellas
ap.add_argument("--huellas", required=True, help="número de huellas")
#Lo que se obtiene es un diccionario (llave:valor) , en este caso llamado args
args = vars(ap.parse_args())
# Los valores del diccionario son cadenas por lo que se tiene que
# transformar a un entero con la función int()
huellas = int(args["huellas"])

recorrido_recursivo(tess,20,huellas)

wn.mainloop()
