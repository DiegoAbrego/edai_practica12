def factorial_no_recursivo(numero):
    fact = 1
    for i in range(numero, 1, -1):
        fact *= i
    return fact

print(str(factorial_no_recursivo(5)))

def factorial_recursivo(numero):
    if numero < 2:
        return 1
    return numero * factorial_recursivo(numero - 1)

print(factorial_recursivo(5))
